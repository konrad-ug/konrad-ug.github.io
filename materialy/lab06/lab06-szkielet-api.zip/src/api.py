from typing import Annotated, Literal

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from src.account import Account
from src.account_registry import AccountRegistry
from src.base_account import BaseAccount
from src.company_account import CompanyAccount
from src.exceptions import AccountNotFoundError, InsufficientFundsError


# --- request and response schemas (pydantic validates the JSON for us) ---

class PersonalAccountIn(BaseModel):
    type: Literal["personal"]
    first_name: str
    last_name: str
    pesel: str
    promo_code: str | None = None


class CompanyAccountIn(BaseModel):
    type: Literal["company"]
    company_name: str
    nip: str


# the "type" field tells pydantic which of the two schemas to use
AccountIn = Annotated[PersonalAccountIn | CompanyAccountIn, Field(discriminator="type")]


class AccountOut(BaseModel):
    account_number: str
    type: Literal["personal", "company"]
    balance: float


class TransferIn(BaseModel):
    sender: str
    recipient: str
    amount: float


class TransferOut(BaseModel):
    sender_balance: float
    recipient_balance: float


def to_account_out(account: BaseAccount) -> AccountOut:
    kind = "personal" if isinstance(account, Account) else "company"
    return AccountOut(account_number=account.account_number, type=kind, balance=account.balance)


def create_app() -> FastAPI:
    app = FastAPI(title="Bank API")
    registry = AccountRegistry()  # lives as long as the app (in memory)

    # --- errors: how exceptions become HTTP status codes ---

    @app.exception_handler(AccountNotFoundError)
    def account_not_found(request: Request, error: AccountNotFoundError):
        return JSONResponse(status_code=404, content={"detail": str(error)})

    # --- endpoints ---

    @app.get("/accounts/{account_number}")
    def get_account(account_number: str) -> AccountOut:
        account = registry.find_by_account_number(account_number)
        if account is None:
            raise AccountNotFoundError(f"Account {account_number} not found")
        return to_account_out(account)

    return app
