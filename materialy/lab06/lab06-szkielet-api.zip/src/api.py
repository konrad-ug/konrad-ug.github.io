from flask import Flask, jsonify, request

from src.account import Account
from src.account_registry import AccountRegistry
from src.company_account import CompanyAccount

app = Flask(__name__)
registry = AccountRegistry()  # accounts live in memory as long as the server runs


@app.route("/api/accounts", methods=["POST"])
def create_account():
    data = request.get_json()
    if data["type"] == "personal":
        account = Account(data["first_name"], data["last_name"], data["pesel"], data.get("promo_code"))
    else:
        account = CompanyAccount(data["company_name"], data["nip"])
    try:
        registry.add_account(account)
    except ValueError as error:
        return jsonify({"message": str(error)}), 422
    return jsonify({"account_number": account.account_number, "balance": account.balance}), 201


@app.route("/api/accounts/<account_number>", methods=["GET"])
def get_account(account_number):
    # TODO: look the account up in the registry (registry.find_by_account_number).
    # No such account: return {"message": "Account not found"} with 404.
    # Otherwise return {"account_number": ..., "balance": ...} with 200.
    # Remove the line below when you are done (501 = Not Implemented).
    return jsonify({"message": "Not implemented"}), 501


@app.route("/api/transfers", methods=["POST"])
def transfer():
    # TODO: read sender, recipient and amount from the JSON body and call registry.transfer(...).
    # Turn the errors into responses: AccountNotFoundError -> 404, InsufficientFundsError -> 409,
    # ValueError -> 422 (the exceptions are in src.exceptions: add the import at the top of the file).
    # Success: return {"message": "Transfer successful"} with 200.
    # Remove the line below when you are done (501 = Not Implemented).
    return jsonify({"message": "Not implemented"}), 501


@app.route("/api/transfers/express", methods=["POST"])
def transfer_express():
    # TODO: like the transfer above, but call registry.transfer_express(...).
    # Remove the line below when you are done (501 = Not Implemented).
    return jsonify({"message": "Not implemented"}), 501


if __name__ == "__main__":
    app.run(port=8000, debug=True)  # http://127.0.0.1:8000
