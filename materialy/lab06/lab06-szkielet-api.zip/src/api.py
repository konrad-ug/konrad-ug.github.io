from flask import Flask, jsonify

from src.account_registry import AccountRegistry

app = Flask(__name__)
registry = AccountRegistry()  # accounts live in memory as long as the server runs


@app.route("/api/accounts/<account_number>", methods=["GET"])
def get_account(account_number):
    account = registry.find_by_account_number(account_number)
    if account is None:
        return jsonify({"message": "Account not found"}), 404
    return jsonify({"account_number": account.account_number, "balance": account.balance}), 200


if __name__ == "__main__":
    app.run(port=8000, debug=True)  # http://127.0.0.1:8000
