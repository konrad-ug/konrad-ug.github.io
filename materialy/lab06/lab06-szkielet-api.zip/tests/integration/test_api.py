import socket
import threading
import time

import httpx
import pytest
import uvicorn

from src.api import create_app


@pytest.fixture(scope="module")
def client():
    """Starts the real API server (uvicorn) on a free port and yields an HTTP client for it.

    scope="module": the server starts once per file, not before every test.
    Tests stay independent because each one creates its own accounts.
    """
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
    server = uvicorn.Server(uvicorn.Config(create_app(), host="127.0.0.1", port=port, log_level="warning"))
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()
    while not server.started:
        time.sleep(0.01)
    with httpx.Client(base_url=f"http://127.0.0.1:{port}") as http_client:
        yield http_client
    server.should_exit = True
    thread.join()


def test_get_missing_account_returns_404(client):
    response = client.get("/accounts/PL00000000000000000000000000")
    assert response.status_code == 404
