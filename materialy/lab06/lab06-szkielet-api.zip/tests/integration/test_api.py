import pytest
import requests

URL = "http://127.0.0.1:8000"  # start the server first (in a separate terminal): python -m src.api


def test_get_missing_account_returns_404():
    # TODO: send GET /api/accounts/<a number that does not exist> and check the status code (404)
    pytest.skip("TODO: write this test")


def test_create_personal_account_returns_201():
    response = requests.post(f"{URL}/api/accounts", json={
        "type": "personal",
        "first_name": "Jan",
        "last_name": "Kowalski",
        "pesel": "90010112354",
    })

    assert response.status_code == 201
    assert response.json()["account_number"].startswith("PL")
    assert response.json()["balance"] == 0


def test_create_personal_account_with_promo_code_starts_with_50():
    # TODO: create a personal account with promo_code "PROM_XYZ" and check that it starts with 50
    pytest.skip("TODO: write this test")


def test_create_company_account_returns_201():
    # TODO: create a company account (company_name, nip) and check 201 and balance 0
    pytest.skip("TODO: write this test")


def test_created_account_can_be_fetched():
    # TODO: create an account, GET it by its account_number and check that you get the same data back
    pytest.skip("TODO: write this test")


def test_create_account_with_invalid_owner_id_returns_422():
    # TODO: use @pytest.mark.parametrize with invalid data (pesel / nip too short) and check 422
    pytest.skip("TODO: write this test")


def create_funded_account():
    # TODO: create a personal account with promo_code "PROM_XYZ" (it starts with 50 PLN) and return its account_number
    pass


def balance_of(account_number):
    # TODO: GET the account and return its balance
    pass


def test_transfer_moves_money():
    # TODO: create two funded accounts, POST /api/transfers, check 200 and both balances
    pytest.skip("TODO: write this test")


def test_transfer_to_a_company_account():
    # TODO: transfer from a funded personal account to a company account, check 200 and the balance
    pytest.skip("TODO: write this test")


def test_transfer_with_invalid_amount_changes_nothing():
    # TODO: use @pytest.mark.parametrize: more than the balance -> 409, zero and negative -> 422;
    # TODO: check that both balances stay the same
    pytest.skip("TODO: write this test")


def test_transfer_with_missing_account_returns_404():
    # TODO: use @pytest.mark.parametrize: unknown sender or unknown recipient -> 404
    pytest.skip("TODO: write this test")


def test_transfer_to_the_same_account_returns_422():
    # TODO: sender and recipient are the same account -> 422, balance unchanged
    pytest.skip("TODO: write this test")


def test_express_transfer_charges_the_fee():
    # TODO: POST /api/transfers/express from a personal account, check 200 and the fee (1 PLN)
    pytest.skip("TODO: write this test")


def test_express_transfer_from_a_company_account_costs_5():
    # TODO: express transfer from a company account costs 5 PLN
    pytest.skip("TODO: write this test")


def test_express_transfer_needs_money_for_the_fee_too():
    # TODO: amount + fee is more than the balance -> 409, balances unchanged
    pytest.skip("TODO: write this test")
