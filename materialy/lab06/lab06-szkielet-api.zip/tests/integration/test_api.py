import requests

URL = "http://127.0.0.1:8000"  # start the server first (in a separate terminal): python -m src.api


def test_get_missing_account_returns_404():
    response = requests.get(f"{URL}/api/accounts/PL00000000000000000000000000")
    assert response.status_code == 404
