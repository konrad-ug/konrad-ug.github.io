import httpx
import pytest

# Start the server first (in a separate terminal):
#   python -m src.api
BASE_URL = "http://127.0.0.1:8000"
client = httpx.Client(base_url=BASE_URL)


def test_get_missing_account_returns_404():
    response = client.get("/accounts/PL00000000000000000000000000")
    assert response.status_code == 404
